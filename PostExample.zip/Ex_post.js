const express = require('express');
const path = require('path');
// const bodyParser = require('body-parser'); //post방식에서 body의 파라미터를 추출 
const app = express();

// app.use(bodyParser.json()); //json파일을 나타내기 위해 중요한 코드
app.use(express.json()); //express 일정 버전 이상부터는 express에 body-parser기능이 내장됨

// app.use(bodyParser.urlencoded({extended:true}));




app.use(express.static(path.join(__dirname, 'public')));


app.post('/', (req,res) => {
    // console.log("vvv");
    console.log(req.body);
    // const result = req.body;
    // res.send(result);
    // res.send('1');
});




// app.use(logger('common'));

// app.use(express.json());
// app.use(express.urlencoded({
//     extended: true
// }))

app.listen('8500',()=>{
    console.log('8500번에서 대기 중...');
})