const data = {
    name: "C302",
    students: 4
};
axios.post('/', data).then((res) => {
    console.log(res);
});