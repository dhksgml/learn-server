const express = require('express');
const router = express.Router();

// const app = express();


router.get('/',function(req,res){
    const name = req.query.query;
    // res.render('index');
    console.log(name);
    // console.log(typeof(name));
    
    if(name === undefined || name == '')
    {
        res.send('Good Bye');
    } else {
        res.send('Hello World');
    }
 
    // next();
});

router.get('/hello/:id',function(req,res){
    res.send('id: '+ req.params.id);
});


module.exports = router;