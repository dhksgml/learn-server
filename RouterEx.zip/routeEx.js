const express = require('express');
// const path = require('path');

const app = express();

// app.set('views',path.join(__dirname,'public'));
// app.set('view engine','Pug');

const indexRouter = require('./public/index'); //public 폴더에 있는 index.js에서
                                // 라우터 모듈을 만든 것을 사용하기 위해 불러 옴

// app.use('/',express.static(path.join(__dirname,'public')));

// app.get('/',function(req, res){
//     console.log(req.query.id);
//     res.send(req.query.id);
// });

app.use('/',indexRouter);

// app.use(express.json());

app.listen('8000',()=>{
    console.log('8000에서 대기중..');
})


